# YOLOv8-Fruits-Detection
This repository contains a YOLOv8-based object detection model designed for identifying various types of fruits. The model is part of a comprehensive system that integrates fruit detection with quality classification to provide a complete solution for fruit assessment.
